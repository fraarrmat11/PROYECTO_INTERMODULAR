package com.example.nexspringboot.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nombre;
    private Integer experienciaActual;
    private Integer monedas;

    @ManyToOne
    @JoinColumn(name = "nivel_id")
    private Nivel nivel;

    private LocalDateTime fechaCreacion = LocalDateTime.now();

    public Usuario(){}

    public Usuario(String nombre) {
        this.nombre = nombre;
        this.experienciaActual = 0;
        this.monedas = 0;
    }

    // Getters y setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Integer getExperienciaActual() { return experienciaActual; }
    public void setExperienciaActual(Integer experienciaActual) { this.experienciaActual = experienciaActual; }

    public Integer getMonedas() { return monedas; }
    public void setMonedas(Integer monedas) { this.monedas = monedas; }

    public Nivel getNivel() { return nivel; }
    public void setNivel(Nivel nivel) { this.nivel = nivel; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
