package com.example.nexspringboot.repository;
import com.example.nexspringboot.model.Habito;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HabitoRepository extends JpaRepository<Habito, Integer> {
}