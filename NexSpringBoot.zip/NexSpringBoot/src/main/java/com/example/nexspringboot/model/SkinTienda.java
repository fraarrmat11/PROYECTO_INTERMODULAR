package com.example.nexspringboot.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class SkinTienda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nombre;
    private Integer precio;
    private String imagenUrl;

    @OneToMany(mappedBy = "skin")
    private List<UsuarioSkin> usuarios;

    public SkinTienda(){}

    public SkinTienda(String nombre, Integer precio, String colorPrincipal, String descripcion, String imagenUrl) {
        this.nombre = nombre;
        this.precio = precio;
        this.imagenUrl = imagenUrl;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Integer getPrecio() { return precio; }
    public void setPrecio(Integer precio) { this.precio = precio; }

    public String getImagenUrl() { return imagenUrl; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl; }

    public List<UsuarioSkin> getUsuarios() { return usuarios; }
    public void setUsuarios(List<UsuarioSkin> usuarios) { this.usuarios = usuarios; }
}
